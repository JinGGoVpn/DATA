#!/bin/sh

RED="\033[31m"
GREEN="\033[32m"
YELLOW="\033[33m"
PLAIN='\033[0m'

red(){
    echo -e "\033[31m\033[01m$1\033[0m"
}

green(){
    echo -e "\033[32m\033[01m$1\033[0m"
}

yellow(){
    echo -e "\033[33m\033[01m$1\033[0m"
}

rm -f warp.conf proxy.conf

chmod +x ./warp-go
clear
yellow "Please select the type of WARP account you want to use"
echo ""
echo -e " ${GREEN}1.${PLAIN} WARP free account ${YELLOW} (default)${PLAIN}"
echo -e " ${GREEN}2.${PLAIN} WARP+"
echo -e " ${GREEN}3.${PLAIN} WARP Teams"
echo ""
read -p "please enter options [1-3]: " account_type
if [[ $account_type == 2 ]]; then
  yellow "How to Obtain CloudFlare WARP Account Key Information: "
  green "PC: Download and install CloudFlare WARP → Settings → Preferences → Accounts → Copy key into script"
  green "Mobile: Download and install 1.1.1.1 APP → Menu → Account → Copy the key to the script"
  echo ""
  yellow "Important: Please make sure that the account status of the 1.1.1.1 APP on your phone or computer is WARP+!"
  echo ""
  read -rp "Enter WARP account license key (26 characters): " warpkey
  until [[ $warpkey =~ ^[A-Z0-9a-z]{8}-[A-Z0-9a-z]{8}-[A-Z0-9a-z]{8}$ ]]; do
    red "WARP account license key format input error, please re-enter!"
    read -rp "Enter WARP account license key (26 characters): " warpkey
  done
  read -rp "Please enter a custom device name, if not entered, the default random device name will be used: " device_name
  [[ -z $device_name ]] && device_name=$(date +%s%N | md5sum | cut -c 1-6)

  wget https://api.zeroteam.top/warp?format=warp-go -O warp.conf && chmod +x warp.conf
  ./warp-go --update --config=./warp.conf --license=$warpkey --device-name=$device_name
elif [[ $account_type == 3 ]]; then
  yellow "Please go to this site：https://web--public--warp-team-api--coia-mfs4.code.run/ Get your WARP Teams account TOKEN"
  read -rp "Please enter the WARP Teams account TOKEN：" teams_token
  if [[ -n $teams_token ]]; then
    read -rp "Please enter a custom device name, if not entered, the default random device name will be used: " device_name
    [[ -z $device_name ]] && device_name=$(date +%s%N | md5sum | cut -c 1-6)
    
    wget https://api.zeroteam.top/warp?format=warp-go -O warp.conf && chmod +x warp.conf
    ./warp-go --update --config=warp.conf --team-config=$teams_token --device-name=$device_name
  else
    red "No WARP Teams account TOKEN entered, script exits!"
    exit 1
  fi
else
  wget https://api.zeroteam.top/warp?format=warp-go -O warp.conf && chmod +x warp.conf
fi

chmod +x warp-go
./warp-go --config=warp.conf --export-wireguard=proxy.conf

clear
green "The WireGuard configuration file for WARP-GO has been successfully generated!"
yellow "The following is the configuration file content:"
red "$(cat proxy.conf)"
echo ""
yellow "The following is the configuration file sharing QR code:"
qrencode -t ansiutf8 < proxy.conf
echo ""
yellow "Please use this method locally: https://blog.misaka.rest/2023/03/12/cf-warp-yxip/ Preferred available Endpoint IP"